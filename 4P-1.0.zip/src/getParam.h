/*prototypes of functions defined in getParam.c*/

int getParamChar(char *param, const char *flag, int argc, char *argv[]);

int checkSumstatPar(char *name, int *par1, float *par2, char *type, const int npar);
